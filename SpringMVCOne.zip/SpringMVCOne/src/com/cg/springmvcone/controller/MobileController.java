package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Mobile;
import com.cg.springmvcone.service.IMobileService;

@Controller
public class MobileController {
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value = "/home")
	public String getAllMobile(@ModelAttribute("my")Mobile mob, Map<String,Object> model){
		List<String> myList = new ArrayList<String>();
		myList.add("Android");
		myList.add("iPhone");
		myList.add("Windows");
		
		model.put("cato", myList);
		
		
		return "AddMobile";
	}
	@RequestMapping(value = "/adddata", method = RequestMethod.POST)
	public String addMobileData(@Valid@ModelAttribute("my") Mobile mob,
			 BindingResult result,Map<String,Object> model){
		if(result.hasErrors()){
			List<String> myList = new ArrayList<String>();
			myList.add("Android");
			myList.add("iPhone");
			myList.add("Windows");
			
			model.put("cato", myList);
			
			return "AddMobile";
		}else{
			mobileservice.addMobile(mob);
			return "success";
		}
		
		//mobileservice.addMobile(mob);
		//System.out.println(mob.getMobId()+" "+mob.getMobName()+" "+mob.getMobPrice()+" "+mob.getMobCategory()+" "+mob.getOnline());
		
		
	}
	
	@RequestMapping(value = "/showall",method = RequestMethod.GET)
	public ModelAndView showAllMobileData(){
		
		List<Mobile> allMobile = mobileservice.showAllMobile();
		//System.out.println(allMobile);
		//ModelAndView(viewName = jsppagename, modelname =key for list object i.e,. allMobile , modelobject = list object name)
		return new ModelAndView("mobileshow","data", allMobile);
		
	}
	
	@RequestMapping(value = "/searchmobile", method = RequestMethod.GET)
	public String searchData(@ModelAttribute("yy") Mobile mob){
		return "searchmobile";
		
	}
	@RequestMapping(value = "/mobilesearch", method = RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Mobile mob){
		
		
		Mobile mobSearch = mobileservice.searchMobile(mob.getMobId());
		//System.out.println(mobSearch);
		return new ModelAndView("showsearchmobile", "temp", mobSearch);
		
	}
	
	
	@RequestMapping(value = "/deletemobile", method = RequestMethod.GET)
	public String deleteMobileData(@ModelAttribute("xy") Mobile mob){
		
		//System.out.println(mob.getMobId()+" "+mob.getMobName()+" "+mob.getMobPrice()+" "+mob.getMobCategory()+" "+mob.getOnline());
		return "deletemobile";
		
	}
	@RequestMapping(value = "/deletedata", method = RequestMethod.POST)
    public String datadelete(@ModelAttribute("xy") Mobile mob){
		
		
		mobileservice.deleteMobile(mob.getMobId());
		return "success";
		
	}
	
}
